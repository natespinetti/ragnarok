"""
Nathan Spinetti
Class: CS 521 - Fall 2
Date: 12/16/23
Term Project
Takes user through Matchmaker Selection process. 
The user is presented with various questions and their answers 
help calculate what Pokemon the user should get.
"""

import random
from pokemon_trainer import PokemonTrainer

class PokemonMatchmaker(PokemonTrainer):
    ''' Provide methods to match a random Pokemon to you based on various questions. '''
    
    def __init__(self):
        self.pokemon_matchmaker(PokemonTrainer.pokedex)

    def __str__(self):
        return f"This Pokedex is for Generation {self.generation}."
    
    def __repr__(self):
        return "Pokedex(1)"
    
    def set_options(self):
        ''' Sets the options for PokemonTrainer if options reduced to 0. '''
        
        PokemonTrainer.mm_questions = ["Please enter your favorite color: ", 
                "Please enter your first name: ", 
                "Please enter the year you were born: ", 
                "Please enter if you drive 'fast' or 'slow': ",
                "When in a hostile situation would you follow 'fight' or 'flight' instincts, please enter one: ", 
                "When in a challenging situation, are you 'patient' or do you take quick 'initiative', please enter one: " 
                ]

        PokemonTrainer.mm_funcs = [self.type_generate, self.length_generate, 
                                   self.year_generate, self.speed_generate, 
                                   self.fight_flight_generate, self.challenge_generate
                                   ]

    
    def pokemon_matchmaker(self, pokedex):
        ''' Randomly chooses between 6 prompts to pick random Pokemon. '''

        # If PokemonTrainer's options 0, reset them
        if len(PokemonTrainer.mm_questions) == 0 or len(PokemonTrainer.mm_funcs) == 0:
            self.set_options()

        # Continue while Pokemon Party len < 6
        while len(PokemonTrainer.pokemon_party) < 6:
            # Get a random question and ask the user that question.
            random_number = random.randint(0, len(PokemonTrainer.mm_questions) - 1)
            user_input = input(f"\n{PokemonTrainer.mm_questions[random_number]}")

            # Get Random Pokemon from function based on user input
            try:
                random_pokemon = PokemonTrainer.mm_funcs[random_number](user_input, pokedex)
                if random_pokemon is None:
                    continue
            except KeyboardInterrupt:
                import sys
                sys.exit()
            except Exception as e:
                print(f"An error occurred: {e}")
                continue
            
            # Call confirmation func, True because it's Matchmaker
            confirmation = self.add_pokemon_confirmation(random_pokemon.Number, True)
            
            # Returns none when Pokemon Party is full
            if confirmation is not None:
                confirm_selection, confirm_add = confirmation
                # If True, Remove Option and Function used. Get new random num
                if confirm_add: 
                    PokemonTrainer.mm_questions.pop(random_number)
                    PokemonTrainer.mm_funcs.pop(random_number)
                    if len(PokemonTrainer.mm_questions) == 0 or len(PokemonTrainer.mm_funcs) == 0:
                        self.set_options()
                    random_number = random.randint(0, len(PokemonTrainer.mm_questions))
                else:
                    continue
                # Call Selection Option
                if confirm_selection == 'manual':
                    from pokemon_manual import PokemonManual
                    PokemonManual()
                else:
                    continue
            else:
                break


    def year_generate(self, year, pokedex):
        ''' Takes a year's last 2 digits and matches it to a Pokemon Number. '''
        year_input = year[2:4]

        # Used to store all matches
        all_pokemon_with_year = []
        # Loop through Pokedex and match year_input to Pokemon Number
        try:
            int(year_input)
            for key, pokemon in pokedex.items():
                if year_input in pokemon.Number:
                    all_pokemon_with_year.append(pokemon)
                elif len(year_input) > 1:
                    # Add year values and see if there is a Pokemon with that Number
                    if str((int(year_input[0]) + int(year_input[1]))) in pokemon.Number:
                        all_pokemon_with_year.append(pokemon)
        except ValueError:
            print(f"'{year}' is not a valid 4 digit year, try again.")
            return None

        print(f"Based off of your birth year '{year}', your Pokemon will be...")

        # Pick a random Pokemon out of the options matched to your birth year
        if all_pokemon_with_year:
            random_pokemon = random.choice(all_pokemon_with_year)
            print(f'{random_pokemon.Name}!')
            return random_pokemon
        else:
            return None

    def type_generate(self, color, pokedex):
        ''' Takes a color input and matches it to a types color for a random Pokemon by Type. '''
        all_colors = ['white', 'red', 'blue', 'green', 'blue', 'brown', 'purple', 
                      'yellow', 'brown', 'gray', 'pink', 'blue', 'green', 'purple', 
                      'silver', 'blue', 'black', 'pink']
        all_types = ['Normal', 'Fire', 'Water', 'Grass', 'Flying', 'Fighting', 
                     'Poison', 'Electric', 'Ground', 'Rock', 'Psychic', 'Ice', 
                     'Bug', 'Ghost', 'Steel', 'Dragon', 'Dark', 'Fairy']
        color_input = color.lower()

        # Match color(s) to their types
        indexes = [index for index, color in enumerate(all_colors) if color == color_input]

        # Check if there are any matching colors
        if indexes:
            # Select a random index from the filtered list
            index = random.choice(indexes)
            print(f"Based off of your color input '{color}', you will be matched with a {all_types[index]} type Pokemon.")
        # If the input doesn't match a type, pair with random Pokemon
        else:
            index = random.randint(0, len(all_colors) - 1)
            print(f'{color} is not one of our color options, you have been randomly matched with a {all_types[index]} type Pokemon.')

        print(f"And that Pokemon will be...")
        
        # Add all Pokemon that match types to list
        all_pokemon_of_type = []
        for key, pokemon in pokedex.items():
            if pokemon.Type1 == all_types[index]:
                all_pokemon_of_type.append(pokemon)
            elif pokemon.Type2 == all_types[index]:
                all_pokemon_of_type.append(pokemon)

        # Pick a random Pokemon from the list
        if all_pokemon_of_type:
            random_pokemon = random.choice(all_pokemon_of_type)
            print(f'{random_pokemon.Name}!')
            return random_pokemon
        else:
            return None



    def length_generate(self, name, pokedex):
        ''' Takes first name input and uses lengths and addition of characters to get a random Pokemon Number. '''
        
        # Get position of first letter in alphabet
        first_letter = lambda first_letter: ord(first_letter[0].upper()) - ord('A') + 1
        # Add unicode value of each character submitted
        add_all = lambda add_all: sum(ord(char) for char in add_all)
        # Generate number based on randint * len name
        name_length = lambda name_length: random.randint(0, 9) * len(name_length)

        options = ['first_letter', 'name_length', 'add_all']

        # Choose a random option
        index = random.choice(options)

        # Get the first, last, and a random Pokemon in the Pokedex
        first_key = int(list(pokedex)[0])
        last_key = int(list(pokedex)[-1])
        rand_key = random.randint(first_key, last_key - 1)

        print(f"Based on your name, '{name}', your new partner is...")

        pokemon_selection = []

        # Set value from lambda funcs
        if index == 'first_letter':
            value = first_letter(name)
        elif index == 'name_length':
            value = name_length(name)
        else:
            value = add_all(name)

        # Make sure it's within the Pokedex range
        first_add = value + first_key
        last_add = last_key - value

        # Add the Pokemon that calculations match to list
        for key, pokemon in pokedex.items():
            if int(pokemon.Number) in [first_add, last_add, rand_key]:
                pokemon_selection.append(pokemon)

        # Choose a random Pokemon from list
        if pokemon_selection:
            random_pokemon = random.choice(pokemon_selection)
            print(f'{random_pokemon.Name}!')
            return random_pokemon
        else:
            return None




    def speed_generate(self, speed, pokedex):
        ''' Takes speed input and picks a random Pokemon with high HP or Speed stats. '''
        speed = speed.lower()

        if speed.count('f') >= 1:
            speed = 'fast'
        else:
            speed = 'slow'

        print(f"Based on how {speed} you drive, you have been paired with...")

        pokemon_selection = []

        # If fast, choose a Pokemon that is fast with less HP
        if speed.count('f') >= 1:
            for key, pokemon in pokedex.items():
                if int(pokemon.Speed) >= 90 and int(pokemon.HP) <= 90:
                    pokemon_selection.append(pokemon)
        # If slow, choose a Pokemon with more HP and is slower
        else:
            for key, pokemon in pokedex.items():
                if int(pokemon.HP) >= 90 and int(pokemon.Speed) <= 90:
                    pokemon_selection.append(pokemon)

        # Choose a random Pokemon from list
        if pokemon_selection:
            random_pokemon = random.choice(pokemon_selection)
            print(f'{random_pokemon.Name}!')
            return random_pokemon
        else:
            return None

    def fight_flight_generate(self, fight_flight, pokedex):
        ''' Takes fight or flight input and picks a random Pokemon with high Attack or Defense stats. '''
        fight_flight = fight_flight.lower()

        if fight_flight.count('l') >= 1:
            fight_flight = 'flight'
        else:
            fight_flight = 'fight'

        print(f"Since you picked {fight_flight}, a good partner for you might be...")

        pokemon_selection = []

        # If the user picks flight, they get a higher Defense Pokemon
        if fight_flight == 'flight' or fight_flight.count('l') >= 1:
            for key, pokemon in pokedex.items():
                if int(pokemon.Defense) >= 90:
                    pokemon_selection.append(pokemon)
        # If fight, choose a Pokemon with higher Attack power
        else:
            for key, pokemon in pokedex.items():
                if int(pokemon.Attack) >= 90:
                    pokemon_selection.append(pokemon)

        # Choose random Pokemon from list
        if pokemon_selection:
            random_pokemon = random.choice(pokemon_selection)
            print(f'{random_pokemon.Name}!')
            return random_pokemon
        else:
            return None

    def challenge_generate(self, challenge, pokedex):
        ''' Takes patient or initiative input and picks a random Pokemon with high Sp.Attack or Sp.Defense stats. '''
        challenge = challenge.lower()

        if challenge.count('p') >= 1:
            challenge = 'patient'
        else:
            challenge = 'initiative'

        print(f"Since you picked {challenge}, a good partner for you might be...")

        pokemon_selection = []

        # If they take initiative, a Pokemon with higher Special Attack is selected
        if challenge == 'initiative' or challenge.count('i') >= 2:
            for key, pokemon in pokedex.items():
                if int(pokemon.SpAttack) >= 90:
                    pokemon_selection.append(pokemon)
        # If patient, they get a Pokemon with higher Special Defense
        else:
            for key, pokemon in pokedex.items():
                if int(pokemon.SpDefense) >= 90:
                    pokemon_selection.append(pokemon)

        # Choose Pokemon from list
        if pokemon_selection:
            random_pokemon = random.choice(pokemon_selection)
            print(f'{random_pokemon.Name}!')
            return random_pokemon
        else:
            return None
        