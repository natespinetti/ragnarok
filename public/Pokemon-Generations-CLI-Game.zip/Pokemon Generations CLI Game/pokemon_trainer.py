"""
Nathan Spinetti
Class: CS 521 - Fall 2
Date: 12/16/23
Term Project
PokemonTrainer class is used to handle the active Pokedex, 
your Pokemon Party, and methods for adding Pokemon.
"""

import copy

class PokemonTrainer:
    ''' PokemonTrainer to handle active Pokedex, Pokemon Party, and methods for adding Pokemon. '''
    
    pokemon_party = set()
    pokedex = dict()
    mm_questions = list()
    mm_funcs = list()
    
    def add_pokemon(self, pokemon):
        ''' Add selected Pokemon to your party. '''
        return self.pokemon_party.add(copy.deepcopy(pokemon))
    
    def add_pokemon_confirmation(self, pokemon, matchmaker):
        ''' Confirmation for adding Pokemon to your party. '''
        # Prints change depending on where you are confirming from
        if matchmaker:
            print(f"\nWould you like to add {self.pokedex[pokemon].Name} to your party?")
        else:
            print(f"You have selected {pokemon}. {self.pokedex[pokemon].Name}. Would you like to add them to your party?")
            
        move_list = list(self.pokedex[pokemon].moves.keys())
        print(f"{self.pokedex[pokemon].Name}'s moves are {', '.join(move_list[:-1]) + ', and ' + move_list[-1]}.")
        try:
            confirmation = input('Yes or No: ')
        except KeyboardInterrupt:
            import sys
            sys.exit()

        # If you want to add selected Pokemon to your party...
        if confirmation.lower().startswith('y'):
            # If the Pokemon is in your party, provide error and begin process again
            if self.pokedex[pokemon] in self.pokemon_party:
                print(f"{self.pokedex[pokemon].Name} is already in your party. Try a different Pokemon.")
                t_f = False
            # If not already in Party, add to Party
            else:
                self.add_pokemon(self.pokedex[pokemon])
                print(f"\n{self.pokedex[pokemon].Name} has been added to your party!")
                t_f = True
        # If you don't go forward with selection, move on        
        else:
            print(f"\n{self.pokedex[pokemon].Name} was not added to your party.")
            t_f = False
        
        # If Party is full, end selection process
        if len(PokemonTrainer.pokemon_party) == 6:
            return
        
        try:
            # Ask if you want to change your selection process
            if matchmaker:
                print("\nWould you like to keep using the Matchmaker?")
                switch = input('Yes or No: ')
                
                # If you want to switch to Manual, import it and switch to that
                if switch.lower().startswith('n'):
                    print('You have switched to Manual Pokemon Selection!')
                    return 'manual', t_f
                else: 
                    return 'matchmaker', t_f
            elif not matchmaker:
                print("\nWould you like to keep using the Manual Selection?")
                switch = input('Yes or No: ')
                
                # If you want to switch to Matchmaker, import it and switch to that
                if switch.lower().startswith('n'):
                    print('You have switched to Pokemon Matchmaker!')
                    return 'matchmaker', t_f
                else: 
                    return 'manual', t_f
        except KeyboardInterrupt:
            import sys
            sys.exit()