"""
Nathan Spinetti
Class: CS 521 - Fall 2
Date: 12/16/23
Term Project
Class to create a Pokemon with it's attributes, type matchups, and moves.
"""

import random

class Pokemon:
    ''' Create a Pokemon based off of various attributes. '''
    
    def __init__(self, attr_dict):
        for key, value in attr_dict.items():
            setattr(self, key, value) # Set attributes based on dictionary input
        self.moves = dict()
        self.set_moves()
        self.Type1 = attr_dict.get('Type 1')
        self.Type2 = attr_dict.get('Type 2')
        self.SpAttack = attr_dict.get('Sp.Attack')
        self.SpDefense = attr_dict.get('Sp.Defense')

    def __str__(self):
        return f"{self.Name} is a {getattr(self, 'Type 1')} type Pokemon with {self.HP} HP and {self.Attack} Attack."
    
    def __repr__(self):
        return "Pokemon({'Number': '251', 'Name': 'Celebi', 'Type 1': 'Psychic', 'Type 2': 'Grass', 'HP': '100', 'Attack': '100', 'Defense': '100', 'Sp.Attack': '100', 'Sp.Defense': '100', 'Speed': '100'})"
    
    def __lt__(self, second_pokemon):
        return int(self.Attack) < int(second_pokemon.Attack)

    def __gt__(self, second_pokemon):
        return int(self.Attack) > int(second_pokemon.Attack)
    
    def _validate_types(self):
        ''' If there is no Type 1, raise error '''
        if not getattr(self, 'Type 1', None):
            self._is_initialized = False
            raise ValueError("Type 1 is required for a Pokemon")

    def set_moves(self):
        ''' Sets the moves for the Pokemon based on it's types. '''
        self._validate_types()
        types = []

        types.append(getattr(self, 'Type 1'))

        # Add Type 2 if it exists
        if hasattr(self, 'Type 2') and getattr(self, 'Type 2') != '':
            types.append(getattr(self, 'Type 2'))
        
        all_type_matchups = list()

        # For each type, get moves
        for type_name in types:
            type_class = class_types.get(type_name)  # Get the class from the dictionary (below)
            if type_class:
                type_instance = type_class()
                self.moves.update(type_instance.get_moves(self)) # update moves with moves from type_class
                all_type_matchups.append(type_instance.type_matchups()) # update matchups for type
        
        # Call the type matchups for the Pokemon
        self.set_type_matchups(all_type_matchups)
        

    def set_type_matchups(self, all_type_matchups):
        ''' Determine the type matchups for the Pokemon. '''
        
        if len(all_type_matchups) == 2:
            combined_matchups = {'Defense': {}, 'Attack': {}}
            # Merge the matchups for types
            for category in combined_matchups:
                # Set initial effects
                for type_, effect in all_type_matchups[0][category].items():
                    combined_matchups[category][type_] = effect
                # Loop through second matchup dict
                for type_, effect in all_type_matchups[1][category].items():
                    # If type exist
                    if type_ in combined_matchups[category]:
                        # Override normal defaults
                        if combined_matchups[category][type_] == 'normal':
                            combined_matchups[category][type_] = effect
                        elif effect in ['no-effect', 'not-effective', 'super-effective']:
                            combined_matchups[category][type_] = effect
                    # If type doesn't already exist, set it
                    else:
                        combined_matchups[category][type_] = effect

            self.type_matchups = combined_matchups
        
        # If one type, set type_matchups
        else:
            self.type_matchups = all_type_matchups[0]


    def move_randomizer(self, moves):
        ''' Pick random moves based on type. '''
        
        move_list = list(moves.keys())
        
        # If there's no Type 2, get 4 moves
        if hasattr(self, 'Type 2') and getattr(self, 'Type 2') == '':
            random_moves = random.sample(move_list, 4)
        # If there is 2 Types, get 2 types per Type
        else: 
            random_moves = random.sample(move_list, 2)
        
        # Set dict with move name and power for random selected moves
        random_moves_with_power = {move_name: moves[move_name] for move_name in random_moves}

        return random_moves_with_power

    class _Normal:
        ''' Normal type functions '''
        def type_matchups(self):
            ''' Set Normal type type matchups '''
            return {'Defense': {'Normal': 'normal', 'Fire': 'normal', 'Water': 'normal', 'Grass': 'normal', 
                                'Flying': 'normal', 'Fighting': 'super-effective', 'Poison': 'normal', 
                                'Electric': 'normal', 'Ground': 'normal', 'Rock': 'normal', 'Psychic': 'normal', 
                                'Ice': 'normal', 'Bug': 'normal', 'Ghost': 'no-effect', 'Steel': 'normal', 
                                'Dragon': 'normal', 'Dark': 'normal', 'Fairy': 'normal'},
                    
                    'Attack': {'Normal': 'normal', 'Fire': 'normal', 'Water': 'normal', 'Grass': 'normal', 
                               'Flying': 'normal', 'Fighting': 'normal', 'Poison': 'normal', 
                               'Electric': 'normal', 'Ground': 'normal', 'Rock': 'not-effective', 'Psychic': 'normal', 
                               'Ice': 'normal', 'Bug': 'normal', 'Ghost': 'no-effect', 'Steel': 'not-effective', 
                               'Dragon': 'normal', 'Dark': 'normal', 'Fairy': 'normal'}}
            
        def get_moves(self, pokemon):
            ''' Set Normal type moves '''
            moves = {'Scratch': 40, 'Attract': 0, 'Bite': 60, 'Body Slam': 85, 'Cut': 50, 'Double Slap': 15, 
                     'Extreme Speed': 80, 'Fury Swipes': 18, 'Growl': 0, 'Headbutt': 70, 'Hyper Beam': 150, 
                     'Leer': 0, 'Pound': 40, 'Quick Attack': 40, 'Rage': 20, 'Roar': 0, 'Smokescreen': 0, 
                     'Strength': 80, 'Tackle': 40}
            return pokemon.move_randomizer(moves)

    class _Fire:
        ''' Fire type functions '''
        def type_matchups(self):
            ''' Set Fire type type matchups '''
            return {'Defense': {'Normal': 'normal', 'Fire': 'not-effective', 'Water': 'super-effective', 'Grass': 'not-effective', 
                                'Flying': 'normal', 'Fighting': 'normal', 'Poison': 'normal', 
                                'Electric': 'normal', 'Ground': 'super-effective', 'Rock': 'super-effective', 'Psychic': 'normal', 
                                'Ice': 'not-effective', 'Bug': 'not-effective', 'Ghost': 'normal', 'Steel': 'not-effective', 
                                'Dragon': 'normal', 'Dark': 'normal', 'Fairy': 'not-effective'},
                    
                    'Attack': {'Normal': 'normal', 'Fire': 'not-effective', 'Water': 'not-effective', 'Grass': 'super-effective', 
                               'Flying': 'normal', 'Fighting': 'normal', 'Poison': 'normal', 
                               'Electric': 'normal', 'Ground': 'normal', 'Rock': 'not-effective', 'Psychic': 'normal', 
                               'Ice': 'super-effective', 'Bug': 'super-effective', 'Ghost': 'normal', 'Steel': 'super-effective', 
                               'Dragon': 'not-effective', 'Dark': 'normal', 'Fairy': 'normal'}}
            
        def get_moves(self, pokemon):
            ''' Set Fire type moves '''
            moves = {'Ember': 40, 'Fire Fang': 65, 'Fire Punch': 75, 'Fire Spin': 35, 'Flame Burst': 70, 
                     'Flamethrower': 90, 'Flame Charge': 50, 'Heat Wave': 95, 'Incinerate': 60, 'Inferno': 100, 
                     'Overheat': 130, 'Sunny Day': 0, 'Will-O-Wisp': 0}
            return pokemon.move_randomizer(moves)

    class _Water:
        ''' Water type functions '''
        def type_matchups(self):
            ''' Set Water type type matchups '''
            return {'Defense': {'Normal': 'normal', 'Fire': 'not-effective', 'Water': 'not-effective', 'Grass': 'super-effective', 
                                'Flying': 'normal', 'Fighting': 'normal', 'Poison': 'normal', 
                                'Electric': 'super-effective', 'Ground': 'normal', 'Rock': 'normal', 'Psychic': 'normal', 
                                'Ice': 'not-effective', 'Bug': 'normal', 'Ghost': 'normal', 'Steel': 'not-effective', 
                                'Dragon': 'normal', 'Dark': 'normal', 'Fairy': 'normal'},
                    
                    'Attack': {'Normal': 'normal', 'Fire': 'super-effective', 'Water': 'not-effective', 'Grass': 'not-effective', 
                               'Flying': 'normal', 'Fighting': 'normal', 'Poison': 'normal', 
                               'Electric': 'normal', 'Ground': 'super-effective', 'Rock': 'super-effective', 'Psychic': 'normal', 
                               'Ice': 'normal', 'Bug': 'normal', 'Ghost': 'normal', 'Steel': 'normal', 
                               'Dragon': 'not-effective', 'Dark': 'normal', 'Fairy': 'normal'}}
            
        def get_moves(self, pokemon):
            ''' Set Water type moves '''
            moves = {'Aqua Jet': 40, 'Aqua Tail': 80, 'Brine': 65, 'Bubble': 40, 'Bubble Beam': 65, 'Dive': 80, 'Hydro Cannon': 150, 
                     'Hydro Pump': 110, 'Jet Punch': 60, 'Rain Dance': 0, 'Razor Shell': 75, 'Scald': 80, 'Splash': 0, 'Surf': 90, 
                     'Water Gun': 40, 'Water Pulse': 60, 'Water Sport': 0, 'Waterfall': 80, 'Whirlpool': 35}
            return pokemon.move_randomizer(moves)

    class _Grass:
        ''' Grass type functions '''
        def type_matchups(self):
            ''' Set Grass type type matchups '''
            return {'Defense': {'Normal': 'normal', 'Fire': 'super-effective', 'Water': 'not-effective', 'Grass': 'not-effective', 
                                'Flying': 'super-effective', 'Fighting': 'normal', 'Poison': 'super-effective', 
                                'Electric': 'not-effective', 'Ground': 'not-effective', 'Rock': 'normal', 'Psychic': 'normal', 
                                'Ice': 'super-effective', 'Bug': 'super-effective', 'Ghost': 'normal', 'Steel': 'normal', 
                                'Dragon': 'normal', 'Dark': 'normal', 'Fairy': 'normal'},
                    
                    'Attack': {'Normal': 'normal', 'Fire': 'not-effective', 'Water': 'super-effective', 'Grass': 'not-effective', 
                               'Flying': 'not-effective', 'Fighting': 'normal', 'Poison': 'not-effective', 
                               'Electric': 'normal', 'Ground': 'super-effective', 'Rock': 'super-effective', 'Psychic': 'normal', 
                               'Ice': 'normal', 'Bug': 'not-effective', 'Ghost': 'normal', 'Steel': 'not-effective', 
                               'Dragon': 'not-effective', 'Dark': 'normal', 'Fairy': 'normal'}}
            
        def get_moves(self, pokemon):
            ''' Set Grass type moves '''
            moves = {'Absorb': 20, 'Bullet Seed': 25, 'Chloroblast': 150, 'Energy Ball': 90, 'Giga Drain': 75, 'Leaf Blade': 90, 
                     'Leaf Storm': 130, 'Leech Seed': 0, 'Magical Leaf': 60, 'Mega Drain': 40, 'Petal Dance': 120, 
                     'Razor Leaf': 65, 'Seed Bomb': 80, 'Sleep Powder': 0, 'Solar Beam': 120, 'Solar Blade': 125, 
                     'Spore': 0, 'Stun Spore': 0, 'Vine Whip': 45}
            return pokemon.move_randomizer(moves)

    class _Flying:
        ''' Flying type functions '''
        def type_matchups(self):
            ''' Set Flying type type matchups '''
            return {'Defense': {'Normal': 'normal', 'Fire': 'normal', 'Water': 'normal', 'Grass': 'not-effective', 
                                'Flying': 'super-effective', 'Fighting': 'not-effective', 'Poison': 'normal', 
                                'Electric': 'normal', 'Ground': 'no-effect', 'Rock': 'super-effective', 'Psychic': 'normal', 
                                'Ice': 'super-effective', 'Bug': 'not-effective', 'Ghost': 'normal', 'Steel': 'normal', 
                                'Dragon': 'normal', 'Dark': 'normal', 'Fairy': 'normal'},
                    
                    'Attack': {'Normal': 'normal', 'Fire': 'normal', 'Water': 'normal', 'Grass': 'super-effective', 
                               'Flying': 'normal', 'Fighting': 'super-effective', 'Poison': 'normal', 
                               'Electric': 'not-effective', 'Ground': 'normal', 'Rock': 'normal', 'Psychic': 'normal', 
                               'Ice': 'normal', 'Bug': 'super-effective', 'Ghost': 'normal', 'Steel': 'not-effective', 
                               'Dragon': 'normal', 'Dark': 'normal', 'Fairy': 'normal'}}
            
        def get_moves(self, pokemon):
            ''' Set Flying type moves '''
            moves = {'Acrobatics': 55, 'Aerial Ace': 60, 'Aeroblast': 100, 'Air Cutter': 60, 'Air Slash': 75, 
                     'Bounce': 85, 'Brave Bird': 120, 'Chatter': 65, 'Defog': 0, 'Drill Peck': 80, 'Feather Dance': 0, 
                     'Fly': 90, 'Gust': 40, 'Hurricane': 110, 'Peck': 35, 'Pluck': 60, 'Roost': 0, 'Tailwind': 0, 'Wing Attack': 60}
            return pokemon.move_randomizer(moves)

    class _Fighting:
        ''' Fighting type functions '''
        def type_matchups(self):
            ''' Set Fighting type type matchups '''
            return {'Defense': {'Normal': 'normal', 'Fire': 'normal', 'Water': 'normal', 'Grass': 'normal', 
                                'Flying': 'super-effective', 'Fighting': 'normal', 'Poison': 'normal', 
                                'Electric': 'normal', 'Ground': 'normal', 'Rock': 'not-effective', 'Psychic': 'super-effective', 
                                'Ice': 'normal', 'Bug': 'not-effective', 'Ghost': 'normal', 'Steel': 'normal', 
                                'Dragon': 'normal', 'Dark': 'not-effective', 'Fairy': 'super-effective'},
                    
                    'Attack': {'Normal': 'super-effective', 'Fire': 'normal', 'Water': 'normal', 'Grass': 'normal', 
                               'Flying': 'not-effective', 'Fighting': 'normal', 'Poison': 'not-effective', 
                               'Electric': 'normal', 'Ground': 'normal', 'Rock': 'super-effective', 'Psychic': 'not-effective', 
                               'Ice': 'super-effective', 'Bug': 'not-effective', 'Ghost': 'no-effect', 'Steel': 'super-effective', 
                               'Dragon': 'normal', 'Dark': 'super-effective', 'Fairy': 'not-effective'}}
            
        def get_moves(self, pokemon):
            ''' Set Fighting type moves '''
            moves = {'Arm Thrust': 15, 'Brick Break': 75, 'Bulk Up': 0, 'Close Combat': 120, 'Detect': 0, 'Double Kick': 30, 
                     'Drain Punch': 75, 'Focus Blast': 120, 'Focus Punch': 150, 'High Jump Kick': 130, 'Jump Kick': 100, 
                     'Quick Guard': 0, 'Revenge': 60, 'Rock Smash': 40, 'Sacred Sword': 90, 'Submission': 80, 'Victory Dance': 0, 
                     'Vital Throw': 70, 'Wake-Up Slap': 70}
            return pokemon.move_randomizer(moves)

    class _Poison:
        ''' Poison type functions '''
        def type_matchups(self):
            ''' Set Poison type type matchups '''
            return {'Defense': {'Normal': 'normal', 'Fire': 'normal', 'Water': 'normal', 'Grass': 'not-effective', 
                                'Flying': 'normal', 'Fighting': 'not-effective', 'Poison': 'not-effective', 
                                'Electric': 'normal', 'Ground': 'super-effective', 'Rock': 'normal', 'Psychic': 'super-effective', 
                                'Ice': 'normal', 'Bug': 'not-effective', 'Ghost': 'normal', 'Steel': 'normal', 
                                'Dragon': 'normal', 'Dark': 'normal', 'Fairy': 'not-effective'},
                    
                    'Attack': {'Normal': 'normal', 'Fire': 'normal', 'Water': 'normal', 'Grass': 'super-effective', 
                               'Flying': 'normal', 'Fighting': 'normal', 'Poison': 'not-effective', 
                               'Electric': 'normal', 'Ground': 'not-effective', 'Rock': 'not-effective', 'Psychic': 'normal', 
                               'Ice': 'normal', 'Bug': 'normal', 'Ghost': 'not-effective', 'Steel': 'no-effect', 
                               'Dragon': 'normal', 'Dark': 'normal', 'Fairy': 'super-effective'}}
            
        def get_moves(self, pokemon):
            ''' Set Poison type moves '''
            moves = {'Acid': 40, 'Acid Armor': 0, 'Acid Spray': 40, 'Clear Smog': 50, 'Cross Poison': 70, 
                     'Dire Claw': 80, 'Poison Fang': 50, 'Poison Gas': 0, 'Poison Jab': 80, 'Poison Powder': 0, 
                     'Poison Sting': 15, 'Poison Tail': 50, 'Purify': 0, 'Sludge': 65, 'Sludge Bomb': 90, 
                     'Sludge Wave': 95, 'Smog': 30, 'Toxic': 0, 'Venoshock': 65}
            return pokemon.move_randomizer(moves)

    class _Electric:
        ''' Electric type functions '''
        def type_matchups(self):
            ''' Set Electric type type matchups '''
            return {'Defense': {'Normal': 'normal', 'Fire': 'normal', 'Water': 'normal', 'Grass': 'normal', 
                                'Flying': 'not-effective', 'Fighting': 'normal', 'Poison': 'normal', 
                                'Electric': 'not-effective', 'Ground': 'super-effective', 'Rock': 'normal', 'Psychic': 'normal', 
                                'Ice': 'normal', 'Bug': 'normal', 'Ghost': 'normal', 'Steel': 'normal', 
                                'Dragon': 'normal', 'Dark': 'normal', 'Fairy': 'normal'},
                    
                    'Attack': {'Normal': 'normal', 'Fire': 'normal', 'Water': 'super-effective', 'Grass': 'not-effective', 
                               'Flying': 'super-effective', 'Fighting': 'normal', 'Poison': 'normal', 
                               'Electric': 'not-effective', 'Ground': 'no-effect', 'Rock': 'normal', 'Psychic': 'normal', 
                               'Ice': 'normal', 'Bug': 'normal', 'Ghost': 'normal', 'Steel': 'normal', 
                               'Dragon': 'not-effective', 'Dark': 'normal', 'Fairy': 'normal'}}
            
        def get_moves(self, pokemon):
            ''' Set Electric type moves '''
            moves = {'Bolt Strike': 130, 'Charge': 0, 'Charge Beam': 50, 'Discharge': 80, 'Electrify': 0, 
                     'Electro Ball': 0, 'Shock Wave': 60, 'Spark': 65, 'Thunder': 110, 'Thunder Fang': 65, 
                     'Thunder Punch': 75, 'Thunder Shock': 40, 'Thunder Wave': 0, 'Thunderbolt': 90, 
                     'Volt Switch': 70, 'Volt Tackle': 120, 'Zap Cannon': 120}
            return pokemon.move_randomizer(moves)

    class _Ground:
        ''' Ground type functions '''
        def type_matchups(self):
            ''' Set Ground type type matchups '''
            return {'Defense': {'Normal': 'normal', 'Fire': 'normal', 'Water': 'super-effective', 'Grass': 'super-effective', 
                                'Flying': 'normal', 'Fighting': 'normal', 'Poison': 'not-effective', 
                                'Electric': 'no-effect', 'Ground': 'normal', 'Rock': 'not-effective', 'Psychic': 'normal', 
                                'Ice': 'super-effective', 'Bug': 'normal', 'Ghost': 'normal', 'Steel': 'normal', 
                                'Dragon': 'normal', 'Dark': 'normal', 'Fairy': 'normal'},
                    
                    'Attack': {'Normal': 'normal', 'Fire': 'super-effective', 'Water': 'normal', 'Grass': 'not-effective', 
                               'Flying': 'no-effect', 'Fighting': 'normal', 'Poison': 'super-effective', 
                               'Electric': 'super-effective', 'Ground': 'normal', 'Rock': 'super-effective', 'Psychic': 'normal', 
                               'Ice': 'normal', 'Bug': 'not-effective', 'Ghost': 'normal', 'Steel': 'super-effective', 
                               'Dragon': 'normal', 'Dark': 'normal', 'Fairy': 'normal'}}
            
        def get_moves(self, pokemon):
            ''' Set Ground type moves '''
            moves = {'Bone Club': 65, 'Bone Rush': 25, 'Dig': 80, 'Drill Run': 80, 'Earth Power': 90, 'Earthquake': 100, 
                     'Fissure': 0, 'Magnitude': 100, 'Max Quake': 110, 'Mud Bomb': 65, 'Mud Shot': 55, 'Mud Sport': 0, 
                     'Mud-Slap': 20, 'Sand Attack': 0, 'Sand Tomb': 35, 'Spikes': 0, 'Stomping Tantrum': 75}
            return pokemon.move_randomizer(moves)

    class _Rock:
        ''' Rock type functions '''
        def type_matchups(self):
            ''' Set Rock type type matchups '''
            return {'Defense': {'Normal': 'not-effective', 'Fire': 'not-effective', 'Water': 'super-effective', 'Grass': 'super-effective', 
                                'Flying': 'not-effective', 'Fighting': 'super-effective', 'Poison': 'not-effective', 
                                'Electric': 'normal', 'Ground': 'super-effective', 'Rock': 'normal', 'Psychic': 'normal', 
                                'Ice': 'normal', 'Bug': 'normal', 'Ghost': 'normal', 'Steel': 'super-effective', 
                                'Dragon': 'normal', 'Dark': 'normal', 'Fairy': 'normal'},
                    
                    'Attack': {'Normal': 'normal', 'Fire': 'super-effective', 'Water': 'normal', 'Grass': 'normal', 
                               'Flying': 'super-effective', 'Fighting': 'not-effective', 'Poison': 'normal', 
                               'Electric': 'normal', 'Ground': 'not-effective', 'Rock': 'normal', 'Psychic': 'normal', 
                               'Ice': 'super-effective', 'Bug': 'super-effective', 'Ghost': 'normal', 'Steel': 'not-effective', 
                               'Dragon': 'normal', 'Dark': 'normal', 'Fairy': 'normal'}}
            
        def get_moves(self, pokemon):
            ''' Set Rock type moves '''
            moves = {'Ancient Power': 60, 'Head Smash': 150, 'Power Gem': 80, 'Rock Blast': 25, 'Rock Polish': 0, 
                     'Rock Slide': 75, 'Rock Throw': 50, 'Rock Tomb': 60, 'Rollout': 30, 'Sandstorm': 0, 
                     'Smack Down': 50, 'Stealth Rock': 0, 'Stone Axe': 65, 'Stone Edge': 100, 'Wide Guard': 0}
            return pokemon.move_randomizer(moves)

    class _Psychic:
        ''' Psychic type functions '''
        def type_matchups(self):
            ''' Set Psychic type type matchups '''
            return {'Defense': {'Normal': 'normal', 'Fire': 'normal', 'Water': 'normal', 'Grass': 'normal', 
                                'Flying': 'normal', 'Fighting': 'not-effective', 'Poison': 'normal', 
                                'Electric': 'normal', 'Ground': 'normal', 'Rock': 'normal', 'Psychic': 'not-effective', 
                                'Ice': 'normal', 'Bug': 'super-effective', 'Ghost': 'super-effective', 'Steel': 'normal', 
                                'Dragon': 'normal', 'Dark': 'super-effective', 'Fairy': 'normal'},
                    
                    'Attack': {'Normal': 'normal', 'Fire': 'normal', 'Water': 'normal', 'Grass': 'normal', 
                               'Flying': 'normal', 'Fighting': 'super-effective', 'Poison': 'super-effective', 
                               'Electric': 'normal', 'Ground': 'normal', 'Rock': 'normal', 'Psychic': 'not-effective', 
                               'Ice': 'normal', 'Bug': 'normal', 'Ghost': 'normal', 'Steel': 'not-effective', 
                               'Dragon': 'normal', 'Dark': 'no-effect', 'Fairy': 'normal'}}
            
        def get_moves(self, pokemon):
            ''' Set Psychic type moves '''
            moves = {'Agility': 0, 'Amnesia': 0, 'Barrier': 0, 'Calm Mind': 0, 'Cosmic Power': 0, 'Confusion': 50, 
                     'Dream Eater': 100, 'Future Sight': 120, 'Light Screen': 0, 'Mystical Power': 70, 'Psybeam': 65, 
                     'Psyblade': 80, 'Psychic': 90, 'Psycho Cut': 70, 'Psyshock': 80, 'Reflect': 0, 'Zen Headbutt': 80}
            return pokemon.move_randomizer(moves)

    class _Ice:
        ''' Ice type functions '''
        def type_matchups(self):
            ''' Set Ice type type matchups '''
            return {'Defense': {'Normal': 'normal', 'Fire': 'super-effective', 'Water': 'normal', 'Grass': 'normal', 
                                'Flying': 'normal', 'Fighting': 'super-effective', 'Poison': 'normal', 
                                'Electric': 'normal', 'Ground': 'normal', 'Rock': 'super-effective', 'Psychic': 'normal', 
                                'Ice': 'not-effective', 'Bug': 'normal', 'Ghost': 'normal', 'Steel': 'super-effective', 
                                'Dragon': 'normal', 'Dark': 'normal', 'Fairy': 'normal'},
                    
                    'Attack': {'Normal': 'normal', 'Fire': 'not-effective', 'Water': 'not-effective', 'Grass': 'super-effective', 
                               'Flying': 'super-effective', 'Fighting': 'normal', 'Poison': 'normal', 
                               'Electric': 'normal', 'Ground': 'super-effective', 'Rock': 'normal', 'Psychic': 'normal', 
                               'Ice': 'not-effective', 'Bug': 'normal', 'Ghost': 'normal', 'Steel': 'not-effective', 
                               'Dragon': 'super-effective', 'Dark': 'normal', 'Fairy': 'normal'}}
            
        def get_moves(self, pokemon):
            ''' Set Ice type moves '''
            moves = {'Blizzard': 110, 'Frost Breath': 60, 'Hail': 0, 'Haze': 0, 'Ice Ball': 30, 'Ice Beam': 90, 
                     'Ice Fang': 65, 'Ice Punch': 75, 'Icy Wind': 55, 'Mist': 0, 'Powder Snow': 40, 'Sheer Cold': 0, 
                     'Icicle Spear': 25, 'Icicle Crash': 85, 'Ice Spinner': 80}
            return pokemon.move_randomizer(moves)

    class _Bug:
        ''' Bug type functions '''
        def type_matchups(self):
            ''' Set Bug type type matchups '''
            return {'Defense': {'Normal': 'normal', 'Fire': 'super-effective', 'Water': 'normal', 'Grass': 'not-effective', 
                                'Flying': 'super-effective', 'Fighting': 'not-effective', 'Poison': 'normal', 
                                'Electric': 'normal', 'Ground': 'not-effective', 'Rock': 'super-effective', 'Psychic': 'normal', 
                                'Ice': 'normal', 'Bug': 'normal', 'Ghost': 'normal', 'Steel': 'normal', 
                                'Dragon': 'normal', 'Dark': 'normal', 'Fairy': 'normal'},
                    
                    'Attack': {'Normal': 'normal', 'Fire': 'not-effective', 'Water': 'normal', 'Grass': 'super-effective', 
                               'Flying': 'not-effective', 'Fighting': 'not-effective', 'Poison': 'not-effective', 
                               'Electric': 'normal', 'Ground': 'normal', 'Rock': 'normal', 'Psychic': 'super-effective', 
                               'Ice': 'normal', 'Bug': 'normal', 'Ghost': 'not-effective', 'Steel': 'not-effective', 
                               'Dragon': 'normal', 'Dark': 'super-effective', 'Fairy': 'not-effective'}}
            
        def get_moves(self, pokemon):
            ''' Set Bug type moves '''
            moves = {'Attack Order': 90, 'Bug Bite': 60, 'Bug Buzz': 90, 'Fury Cutter': 40, 'Heal Order': 0, 'Leech Life': 80, 
                     'Megahorn': 120, 'Pin Missile': 25, 'Pounce': 50, 'Powder': 0, 'Rage Powder': 0, 'Silk Trap': 0, 
                     'String Shot': 0, 'Struggle Bug': 50, 'Twineedle': 25, 'U-turn': 75}
            return pokemon.move_randomizer(moves)

    class _Ghost:
        ''' Ghost type functions '''
        def type_matchups(self):
            ''' Set Ghost type type matchups '''
            return {'Defense': {'Normal': 'no-effect', 'Fire': 'normal', 'Water': 'normal', 'Grass': 'normal', 
                                'Flying': 'normal', 'Fighting': 'no-effect', 'Poison': 'not-effective', 
                                'Electric': 'normal', 'Ground': 'normal', 'Rock': 'normal', 'Psychic': 'normal', 
                                'Ice': 'normal', 'Bug': 'not-effective', 'Ghost': 'super-effective', 'Steel': 'normal', 
                                'Dragon': 'normal', 'Dark': 'super-effective', 'Fairy': 'normal'},
                    
                    'Attack': {'Normal': 'no-effect', 'Fire': 'normal', 'Water': 'normal', 'Grass': 'normal', 
                               'Flying': 'normal', 'Fighting': 'normal', 'Poison': 'normal', 
                               'Electric': 'normal', 'Ground': 'normal', 'Rock': 'normal', 'Psychic': 'super-effective', 
                               'Ice': 'normal', 'Bug': 'normal', 'Ghost': 'super-effective', 'Steel': 'normal', 
                               'Dragon': 'normal', 'Dark': 'not-effective', 'Fairy': 'normal'}}
            
        def get_moves(self, pokemon):
            ''' Set Ghost type moves '''
            moves = {'Astonish': 30, 'Confuse Ray': 0, 'Curse': 0, 'Hex': 65, 'Lick': 30, 'Night Shade': 0, 
                     'Nightmare': 0, 'Ominous Wind': 60, 'Phantom Force': 90, 'Rage Fist': 50, 'Shadow Ball': 80, 
                     'Shadow Bone': 85, 'Shadow Claw': 70, 'Shadow Force': 120, 'Shadow Punch': 60, 
                     'Shadow Sneak': 40, 'Spite': 0}
            return pokemon.move_randomizer(moves)

    class _Steel:
        ''' Steel type functions '''
        def type_matchups(self):
            ''' Set Steel type type matchups '''
            return {'Defense': {'Normal': 'not-effective', 'Fire': 'super-effective', 'Water': 'normal', 'Grass': 'not-effective', 
                                'Flying': 'not-effective', 'Fighting': 'super-effective', 'Poison': 'no-effect', 
                                'Electric': 'normal', 'Ground': 'super-effective', 'Rock': 'not-effective', 'Psychic': 'not-effective', 
                                'Ice': 'not-effective', 'Bug': 'not-effective', 'Ghost': 'normal', 'Steel': 'not-effective', 
                                'Dragon': 'not-effective', 'Dark': 'normal', 'Fairy': 'not-effective'},
                    
                    'Attack': {'Normal': 'normal', 'Fire': 'not-effective', 'Water': 'not-effective', 'Grass': 'normal', 
                               'Flying': 'normal', 'Fighting': 'normal', 'Poison': 'normal', 
                               'Electric': 'not-effective', 'Ground': 'normal', 'Rock': 'super-effective', 'Psychic': 'normal', 
                               'Ice': 'super-effective', 'Bug': 'normal', 'Ghost': 'normal', 'Steel': 'not-effective', 
                               'Dragon': 'normal', 'Dark': 'normal', 'Fairy': 'super-effective'}}
            
        def get_moves(self, pokemon):
            ''' Set Steel type moves '''
            moves = {'Automize': 0, 'Bullet Punch': 40, 'Flash Cannon': 80, 'Gyro Ball': 100, 'Iron Defense': 0, 
                     'Iron Head': 80, 'Iron Tail': 100, 'Magnet Bomb': 60, 'Metal Burst': 50, 'Metal Claw': 50, 
                     'Metal Sound': 0, 'Mirror Shot': 65, 'Spin Out': 100, 'Steel Beam': 140, 'Steel Wing': 70}
            return pokemon.move_randomizer(moves)

    class _Dragon:
        ''' Dragon type functions '''
        def type_matchups(self):
            ''' Set Dragon type type matchups '''
            return {'Defense': {'Normal': 'normal', 'Fire': 'not-effective', 'Water': 'not-effective', 'Grass': 'not-effective', 
                                'Flying': 'normal', 'Fighting': 'normal', 'Poison': 'normal', 
                                'Electric': 'not-effective', 'Ground': 'normal', 'Rock': 'normal', 'Psychic': 'normal', 
                                'Ice': 'super-effective', 'Bug': 'normal', 'Ghost': 'normal', 'Steel': 'normal', 
                                'Dragon': 'super-effective', 'Dark': 'normal', 'Fairy': 'super-effective'},
                    
                    'Attack': {'Normal': 'normal', 'Fire': 'normal', 'Water': 'normal', 'Grass': 'normal', 
                               'Flying': 'normal', 'Fighting': 'normal', 'Poison': 'normal', 
                               'Electric': 'normal', 'Ground': 'normal', 'Rock': 'normal', 'Psychic': 'normal', 
                               'Ice': 'normal', 'Bug': 'normal', 'Ghost': 'normal', 'Steel': 'not-effective', 
                               'Dragon': 'super-effective', 'Dark': 'normal', 'Fairy': 'no-effect'}}
            
        def get_moves(self, pokemon):
            ''' Set Dragon type moves '''
            moves = {'Clanging Scales': 110, 'Core Enforcer': 100, 'Draco Meteor': 130, 'Dragon Breath': 60, 
                     'Dragon Claw': 80, 'Dragon Dance': 0, 'Dragon Energy': 150, 'Dragon Pulse': 85, 'Dragon Rush': 100, 
                     'Dragon Tail': 60, 'Dual Chop': 40, 'Dynamax Cannon': 100, 'Glaive Rush': 120, 'Order Up': 80, 
                     'Outrage': 120, 'Roar of Time': 150, 'Scale Shot': 25, 'Spacial Rend': 100, 'Twister': 40}
            return pokemon.move_randomizer(moves)

    class _Dark:
        ''' Dark type functions '''
        def type_matchups(self):
            ''' Set Dark type type matchups '''
            return {'Defense': {'Normal': 'normal', 'Fire': 'normal', 'Water': 'normal', 'Grass': 'normal', 
                                'Flying': 'normal', 'Fighting': 'super-effective', 'Poison': 'normal', 
                                'Electric': 'normal', 'Ground': 'normal', 'Rock': 'normal', 'Psychic': 'no-effect', 
                                'Ice': 'normal', 'Bug': 'super-effective', 'Ghost': 'not-effective', 'Steel': 'normal', 
                                'Dragon': 'normal', 'Dark': 'not-effective', 'Fairy': 'super-effective'},
                    
                    'Attack': {'Normal': 'normal', 'Fire': 'normal', 'Water': 'normal', 'Grass': 'normal', 
                               'Flying': 'normal', 'Fighting': 'not-effective', 'Poison': 'normal', 
                               'Electric': 'normal', 'Ground': 'normal', 'Rock': 'normal', 'Psychic': 'super-effective', 
                               'Ice': 'normal', 'Bug': 'normal', 'Ghost': 'super-effective', 'Steel': 'normal', 
                               'Dragon': 'normal', 'Dark': 'not-effective', 'Fairy': 'not-effective'}}
            
        def get_moves(self, pokemon):
            ''' Set Dark type moves '''
            moves = {'Assurance': 60, 'Beat Up': 0, 'Bite': 60, 'Brutal Swing': 60, 'Crunch': 80, 'Dark Pulse': 80, 
                     'Fake Tears': 0, 'Feint Attack': 60, 'Flatter': 0, 'Fling': 50, 'Foul Play': 95, 'Hone Claws': 0, 
                     'Nasty Plot': 0, 'Night Slash': 70, 'Payback': 50, 'Pursuit': 40, 'Snarl': 55, 'Snatch': 0, 
                     'Sucker Punch': 70, 'Taunt': 0, 'Thief': 60, 'Throat Chop': 80}
            return pokemon.move_randomizer(moves)

    class _Fairy:
        ''' Fairy type functions '''
        def type_matchups(self):
            ''' Set Fairy type type matchups '''
            return {'Defense': {'Normal': 'normal', 'Fire': 'normal', 'Water': 'normal', 'Grass': 'normal', 
                                'Flying': 'normal', 'Fighting': 'not-effective', 'Poison': 'super-effective', 
                                'Electric': 'normal', 'Ground': 'normal', 'Rock': 'normal', 'Psychic': 'normal', 
                                'Ice': 'normal', 'Bug': 'not-effective', 'Ghost': 'normal', 'Steel': 'super-effective', 
                                'Dragon': 'no-effect', 'Dark': 'not-effective', 'Fairy': 'normal'},
                    
                    'Attack': {'Normal': 'normal', 'Fire': 'not-effective', 'Water': 'normal', 'Grass': 'normal', 
                               'Flying': 'normal', 'Fighting': 'super-effective', 'Poison': 'not-effective', 
                               'Electric': 'normal', 'Ground': 'normal', 'Rock': 'normal', 'Psychic': 'normal', 
                               'Ice': 'normal', 'Bug': 'normal', 'Ghost': 'normal', 'Steel': 'not-effective', 
                               'Dragon': 'super-effective', 'Dark': 'super-effective', 'Fairy': 'normal'}}
            
        def get_moves(self, pokemon):
            ''' Set Fairy type moves '''
            moves = {'Baby-Doll Eyes': 0, 'Charm': 0, 'Dazzling Gleam': 80, 'Disarming Voice': 40, 'Draining Kiss': 50, 
                     'Fairy Wind': 40, 'Fleur Cannon': 130, 'Flower Shield': 0, 'Light of Ruin': 140, 'Moonblast': 95, 
                     'Moonlight': 0, 'Play Rough': 80, 'Spirit Break': 75, 'Sweet Kiss': 0, 'Twinkle Tackle': 40}
            return pokemon.move_randomizer(moves)

# used in set_moves() to determine class
class_types = {
    'Normal': Pokemon._Normal,
    'Fire': Pokemon._Fire,
    'Water': Pokemon._Water,
    'Grass': Pokemon._Grass,
    'Flying': Pokemon._Flying,
    'Fighting': Pokemon._Fighting,
    'Poison': Pokemon._Poison,
    'Electric': Pokemon._Electric,
    'Ground': Pokemon._Ground,
    'Rock': Pokemon._Rock,
    'Psychic': Pokemon._Psychic,
    'Ice': Pokemon._Ice,
    'Bug': Pokemon._Bug,
    'Ghost': Pokemon._Ghost,
    'Steel': Pokemon._Steel,
    'Dragon': Pokemon._Dragon,
    'Dark': Pokemon._Dark,
    'Fairy': Pokemon._Fairy
}