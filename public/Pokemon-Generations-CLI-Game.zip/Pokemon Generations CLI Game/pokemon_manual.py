"""
Nathan Spinetti
Class: CS 521 - Fall 2
Date: 12/16/23
Term Project
Takes user through Manual Selection process. 
The user can enter a Pokemon Entry Number or a Name.
"""

from pokemon_trainer import PokemonTrainer

class PokemonManual(PokemonTrainer):
    ''' Provide method to manually select Pokemon by Name or Number. '''
    
    def __init__(self):
        self.pokemon_manual(PokemonTrainer.pokedex)

    def __str__(self):
        return f"This Pokedex is for Generation {self.generation}."
    
    def __repr__(self):
        return "PokemonManual()"
    
    def pokemon_manual(self, pokedex):
        ''' Takes number or name as input and adds the Pokemon to the Trainer's Party '''
        
        # Get first and last pokemon index
        first_key = list(pokedex)[0]
        last_key = list(pokedex)[-1]
        
        # Continue as long as Pokemon Party len < 6
        while len(PokemonTrainer.pokemon_party) < 6:
            user_input = input(f"\nPlease enter a Pokemon name or Pokemon entry number from {first_key}-{last_key}: ")

            # Try matching the Input to a Pokemon Number
            try:
                user_input_int = int(user_input)
                user_input_conv = f"{user_input_int:03}"

                # If not a Pokemon in this Generation
                if not int(first_key) <= user_input_int <= int(last_key):
                    print(f"{user_input_conv} is not a Pokemon in this generation, please type a number between {first_key}-{last_key}.")
                    continue  # Go to the next iteration of the loop
                pass

            # If not valid integer for Try, check by Pokemon Name
            except ValueError:
                user_input_conv = user_input.capitalize()
                name_found = False
                
                # Loop through each Pokemon and check if input matches Pokemon Name
                for key, pokemon in pokedex.items():
                    if pokemon.Name == user_input_conv:
                        name_found = True
                        user_input_conv = key
                        break

                # If Pokemon Name not found, provide error message
                if not name_found:
                    print(f"{user_input} is not a Pokemon in this generation, try again.")
                    
            except KeyboardInterrupt:
                import sys
                sys.exit()

            # If neither Number or Name match input, print error
            except:
                print(f"{user_input} is not a valid number, please type a number between {first_key}-{last_key}.")
            
            # Call confirmation func, False because is not Matchmaker
            confirmation = self.add_pokemon_confirmation(user_input_conv, False)
            
            # Returns none when Pokemon Party is full
            if confirmation is not None:
                confirm_selection, confirm_add = confirmation
                # If False, continue with Manual Selection
                if not confirm_add:
                    continue
                # Call Selection Option
                if confirm_selection == 'matchmaker':
                    from pokemon_matchmaker import PokemonMatchmaker
                    PokemonMatchmaker()
                else:
                    continue
            else:
                break