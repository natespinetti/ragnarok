"""
Nathan Spinetti
Class: CS 521 - Fall 2
Date: 12/16/23
Term Project
Unit test for the Pokemon Matchmaker program.
"""

import unittest
from pokemon import Pokemon
from pokedex import Pokedex

class TestPokemon(unittest.TestCase):
    ''' Test Pokemon functionality '''

    def test_pokemon_initialization(self):
        ''' Test Pokemon creation '''
        attr_dict = {
            'Number': '001',
            'Name': 'Bulbasaur',
            'Type 1': 'Grass',
            'Type 2': 'Poison',
            'HP': '45',
            'Attack': '49',
            'Defense': '49',
            'Sp.Attack': '65',
            'Sp.Defense': '65',
            'Speed': '45',
        }
        pokemon = Pokemon(attr_dict)
        self.assertEqual(pokemon.Name, 'Bulbasaur')
        self.assertEqual(pokemon.Type1, 'Grass')
        self.assertEqual(pokemon.Type2, 'Poison')
        self.assertEqual(pokemon.HP, '45')
        self.assertEqual(pokemon.Attack, '49')
        self.assertEqual(pokemon.Defense, '49')
        self.assertEqual(pokemon.SpAttack, '65')
        self.assertEqual(pokemon.SpDefense, '65')
        self.assertEqual(pokemon.Speed, '45')
        self.assertTrue(len(pokemon.moves) > 0)

    def test_comparison_operators(self):
        ''' Test less than and greater than properties (compares by Attack) '''
        bulbasaur_attr = {
            'Number': '001',
            'Name': 'Bulbasaur',
            'Type 1': 'Grass',
            'Type 2': 'Poison',
            'HP': '45',
            'Attack': '49',
            'Defense': '49',
            'Sp.Attack': '65',
            'Sp.Defense': '65',
            'Speed': '45',
        }

        venusaur_attr = {
            'Number': '003',
            'Name': 'Venusaur',
            'Type 1': 'Grass',
            'Type 2': 'Poison',
            'HP': '80',
            'Attack': '82',
            'Defense': '83',
            'Sp.Attack': '100',
            'Sp.Defense': '100',
            'Speed': '80',
        }
        bulbasaur = Pokemon(bulbasaur_attr)
        venusaur = Pokemon(venusaur_attr)
        self.assertTrue(venusaur > bulbasaur)
        self.assertFalse(venusaur < bulbasaur)


class TestPokedex(unittest.TestCase):
    ''' Test Pokedex functionality '''

    def test_pokedex_initialization(self):
        ''' Create a Pokedex from Generation 1 '''
        pokedex = Pokedex(1)
        self.assertIn("001", pokedex.pokemon)
        self.assertIn("004", pokedex.pokemon)
        self.assertIsInstance(pokedex.pokemon["001"], Pokemon)
        self.assertIsInstance(pokedex.pokemon["004"], Pokemon)
        self.assertEqual(pokedex.pokemon["001"].Name, "Bulbasaur")
        self.assertEqual(pokedex.pokemon["004"].Name, "Charmander")

if __name__ == '__main__':
    unittest.main()
