"""
Nathan Spinetti
Class: CS 521 - Fall 2
Date: 12/16/23
Term Project
Program lets you choose a Pokemon Party and battle a wild Pokemon
"""

from pokedex import Pokedex
from pokemon_matchmaker import PokemonMatchmaker
from pokemon_manual import PokemonManual
from pokemon_trainer import PokemonTrainer
import random
import sys

def choose_generation():
    ''' Take user input and return Gen Selection and a Pokedex '''
    generations = ['Gen 1', 'Gen 2', 'Gen 3', 'Gen 4', 'Gen 5', 'Gen 6', 
                   'Gen 7', 'Gen 8', 'Gen 9']
    print("\nChoose from Pokemon Generations 1-9.")

    # Loop through generation selection process
    while True:
        try:
            # If user input is a valid generation, continue
            user_input = int(input("Enter your choice (number): "))
            if 1 <= user_input <= len(generations):
                pass
            else:
                print("Invalid choice, please try again.")
                continue
        except ValueError:
            print("Invalid input, please enter a number from 1-9.")
        except KeyboardInterrupt:
            sys.exit()
        else:
            # Confirm generation selection and return that gen's Pokedex 
            # and gen # in tuple
            print(f"You have selected Gen {user_input}. Are you sure?")
            try:
                confirmation = input('Yes or No: ')
            except KeyboardInterrupt:
                sys.exit()
            if confirmation.lower().startswith('y'):
                return generations[user_input - 1], Pokedex(user_input)

def pick_pokemon():
    ''' Let user decide how they want to build their Pokemon party '''
    print("\nWould you like to enter the Pokemon Matchmaker or Manual Selection?")

    # Loop through choice selection or help
    while True:
        try:
            user_input = input("Enter your choice (type 'matchmaker', 'manual', or 'help' for an explanation): ")

            # If input contains 2 m's, return PokemonMatchmaker
            if user_input == 'matchmaker' or user_input.count('m') == 2:
                print("You have selected Pokemon Matchmaker.")
                return PokemonMatchmaker()
            
             # If input is Manual, return PokemonManual
            elif user_input == 'manual':
                print("You have selected Manual Selection.")
                return PokemonManual()
            
            # If input is help, provide a brief explanation
            elif user_input == 'help':
                print("\nThe Pokemon Matchmaker takes you through a series of questions to match you with the perfect partner!\n" +
                      "Manual Selection lets you type in the name of a Pokemon or the entry number for the Pokemon to make your selection.\n")
                continue
            else:
                print(f"{user_input} is invalid, please enter 'matchmaker' or 'manual'.")
        except KeyboardInterrupt:
            sys.exit()
        except Exception as e:
            print(f"An unexpected error occurred: {e}")
            break
    
def attack(attacking_pokemon, defending_pokemon, move_index, is_trainer):
    ''' Attack damage calculator for Pokemon Battles. '''
    
    # Get the attacker move name and the damage it does
    move_name = list(attacking_pokemon.moves)[move_index]
    move_value = int(attacking_pokemon.moves[move_name])

    if is_trainer:
        print(f"{attacking_pokemon.Name} used {move_name} on the wild {defending_pokemon.Name}.")
    else:
        print(f"The wild {attacking_pokemon.Name} used {move_name} on your {defending_pokemon.Name}.")

    # If the move is in slot 0 or 1, it's from Type 1. Else it is Type 2
    if move_index in [0, 1]:
        move_type = attacking_pokemon.Type1
    elif move_index in [2, 3] and attacking_pokemon.Type2 != '':
        move_type = attacking_pokemon.Type2
    else:
        move_type = attacking_pokemon.Type1

    # Get the defending Pokemon's Type's
    if defending_pokemon.Type2 != '':
        defending_types = (defending_pokemon.Type1, defending_pokemon.Type2)
    else:
        defending_types = defending_pokemon.Type1

    # Determine how effective the move will be, defaulting to normal and 1
    effectiveness = 1
    effectiveness_word = 'normal'
    if move_value != 0:
        if len(defending_types) == 2:
            
            # If there are multiple types, go through 
            # and determine how effective
            for defending_type in defending_types:
                # If in loop it is set to no-effect, stay no-effect. 
                # Ensure you are looking at the right move type.
                if (effectiveness_word != 'no-effect' 
                    and defending_type == move_type):
                    # If first loop sets to super-effective, don't override
                    if (attacking_pokemon.type_matchups['Attack'][defending_type] == 'not-effective' 
                        and effectiveness_word != 'super-effective'):
                        effectiveness = .5
                        effectiveness_word = 'not-effective'
                    elif attacking_pokemon.type_matchups['Attack'][defending_type] == 'super-effective':
                        effectiveness = 2
                        effectiveness_word = 'super-effective'
                    elif attacking_pokemon.type_matchups['Attack'][defending_type] == 'no-effect':
                        effectiveness = 0
                        effectiveness_word = 'no-effect'
        # Same as above but for single type Pokemon
        else:
            if effectiveness_word != 'no-effect' and defending_types == move_type:
                if (attacking_pokemon.type_matchups['Attack'][defending_types] == 'not-effective'
                    and effectiveness_word != 'super-effective'):
                    effectiveness = .5
                    effectiveness_word = 'not-effective'
                if attacking_pokemon.type_matchups['Attack'][defending_types] == 'super-effective':
                    effectiveness = 2
                    effectiveness_word = 'super-effective'
                if attacking_pokemon.type_matchups['Attack'][defending_types] == 'no-effect':
                    effectiveness = 0
                    effectiveness_word = 'no-effect'

    # if move has no effect or the move doesn't have a damage value, attack is 0
    if effectiveness == 0 or move_value == 0:
        attack = 0
    # Attack power = ((Base Pokemon Attack stat / 10) + (The moves attack power / 10)) * how effective it is to the defending Pokemon
    else:
        attack = int((((int(attacking_pokemon.Attack) / 10) + (move_value / 10))  * effectiveness))

    enter_input = input()
    # Provide a message with how effective the move was. If normal effectiveness, no message
    if not enter_input:
        if effectiveness_word == 'not-effective' or effectiveness_word == 'super-effective':
            print(f"{move_name} was {effectiveness_word} against {defending_pokemon.Name}.")
        elif effectiveness_word == 'no-effect':
            print(f"{move_name} had {effectiveness_word} against {defending_pokemon.Name}.")

    # Adjust the defending Pokemon's HP attribute based on attack power
    defending_pokemon.HP = int(defending_pokemon.HP) - attack
    print(f"It did {attack} damage, bringing {defending_pokemon.Name}'s HP to {defending_pokemon.HP}.")

    # If you are the attacker and the defender HP <= 0, you win!
    if is_trainer:
        if int(defending_pokemon.HP) <= 0:
            print(f"\nYou have defeated {random_encounter.Name}!")
            return
    
    # If the attacker is a wild encounter, and the defender's (you) HP <= 0, your Pokemon fainted
    if not is_trainer:
        if int(defending_pokemon.HP) <= 0:
            print(f"{defending_pokemon.Name} has fainted.")
            PokemonTrainer.pokemon_party.remove(defending_pokemon)
            return
    
def pokemon_battle(random_encounter):
    ''' Play out the battle with the wild encounter. '''
    
    # Keep battling as long as wild encounter has HP
    while int(random_encounter.HP) > 0:
        # Loop through your pokemon party
        for pokemon in PokemonTrainer.pokemon_party:
            # Each turn, you and opponent get new move (4 move options)
            your_move = random.randint(0, 3)
            their_move = random.randint(0, 3)

            # if wild encounter fainted, end
            if int(random_encounter.HP) <= 0:
                break

            # if your pokemon fainted, next Pokemon
            if int(pokemon.HP) <= 0:
                continue
            
            try:
                enter_input = input()
            except KeyboardInterrupt:
                sys.exit()
            # Send out your Pokemon!
            if not enter_input or enter_input:
                print(f"Go {pokemon.Name}!!")

                # If your Pokemon is faster, you go first
                if pokemon.Speed > random_encounter.Speed:
                    try:
                        enter_input = input()
                    except KeyboardInterrupt:
                        sys.exit()
                    if not enter_input or enter_input:
                        # Your attack
                        attack(pokemon, random_encounter, your_move, True)
                        
                        # If wild encounter faints, end
                        if int(random_encounter.HP) <= 0:
                            break
                        
                    try:
                        enter_input = input()
                    except KeyboardInterrupt:
                        sys.exit()
                    if not enter_input or enter_input:
                        # Their attack
                        attack(random_encounter, pokemon, their_move, False)
                        
                        # If your Pokemon faints, end turn
                        if int(pokemon.HP) <= 0:
                            break
                    
                    # Return Pokemon after attack sequence
                    try:
                        enter_input = input()
                    except KeyboardInterrupt:
                        sys.exit()
                    if not enter_input or enter_input:
                        print(f"\nGood job {pokemon.Name}, now take a rest.\n")
                        
                # If the wild Pokemon is faster
                else:
                    try:
                        enter_input = input()
                    except KeyboardInterrupt:
                        sys.exit()
                    if not enter_input or enter_input:
                        # Their attack
                        attack(random_encounter, pokemon, their_move, False)
                        
                        # If your Pokemon faints, end turn
                        if int(pokemon.HP) <= 0:
                            break
                        
                    try:
                        enter_input = input()
                    except KeyboardInterrupt:
                        sys.exit()
                    if not enter_input or enter_input:
                        # Your attack
                        attack(pokemon, random_encounter, your_move, True)
                        
                        # If wild encounter faints, end
                        if int(random_encounter.HP) <= 0:
                            break
                    
                    # Return Pokemon after attack sequence
                    try:
                        enter_input = input()
                    except KeyboardInterrupt:
                        sys.exit()
                    if not enter_input or enter_input:
                        print(f"\nGood job {pokemon.Name}, now take a rest.\n")

        # If wild encounter faints, end
        if int(random_encounter.HP) <= 0:
            break

if __name__ == "__main__":
    
    # Infinite loop so you can keep playing
    while True:
        user_choice = choose_generation()
        print(f"\nYou selected: {user_choice[0]}")
        
        # Set the trainers active Pokedex
        PokemonTrainer.pokedex = user_choice[1].pokemon

        # Keep adding Pokemon to part as long as len < 6
        while len(PokemonTrainer.pokemon_party) < 6:
            pick_pokemon()

        # Sort Pokemon Party by attack power
        PokemonTrainer.pokemon_party = sorted(list(PokemonTrainer.pokemon_party), reverse=True)
        
        print('\nCongrats! You have completed your Pokemon Party!')
        print('\nHere are all of your members:\n')

        # Print and write Pokemon Party with stats
        with open('pokemon_party.txt', 'w') as output:
            
            # Following Print and Write are column headings
            print(f'{"#":^{3}} {"Name":^{10}} {"Type 1":^{10}} {"Type 2":^{10}} ' + 
                f'{"HP":^{10}} {"Attack":^{10}} {"Defense":^{10}}' +
                f'{"Sp. Attack":^{10}} {"Sp. Defense":^{10}} {"Speed":^{10}}')
            
            output.write(f'{"#":^{3}} {"Name":^{10}} {"Type 1":^{10}} {"Type 2":^{10}} ' + 
                f'{"HP":^{10}} {"Attack":^{10}} {"Defense":^{10}}' +
                f'{"Sp. Attack":^{10}} {"Sp. Defense":^{10}} {"Speed":^{10}}\n')
            
            # Loop through Pokemon Party and Print and Write their stats
            for i, pokemon in enumerate(PokemonTrainer.pokemon_party):
                print(f'{i+1:^{3}} {pokemon.Name:^{10}} {pokemon.Type1:^{10}} {pokemon.Type2:^{10}} ' + 
                    f'{pokemon.HP:^{10}} {pokemon.Attack:^{10}} {pokemon.Defense:^{10}}' +
                    f'{pokemon.SpAttack:^{10}} {pokemon.SpDefense:^{10}} {pokemon.Speed:^{10}}')

                output.write(f'{i+1:^{3}} {pokemon.Name:^{10}} {pokemon.Type1:^{10}} {pokemon.Type2:^{10}} ' + 
                    f'{pokemon.HP:^{10}} {pokemon.Attack:^{10}} {pokemon.Defense:^{10}}' +
                    f'{pokemon.SpAttack:^{10}} {pokemon.SpDefense:^{10}} {pokemon.Speed:^{10}}\n')
            
            print('\nYour game has been saved to: pokemon_party.txt')
        
        # Encounter a wild Pokemon!
        random_encounter = user_choice[1].random_pokemon

        try:
            enter_input = input('\n\nPress ENTER to continue...')
        except KeyboardInterrupt:
            sys.exit()
        if not enter_input or enter_input:
            print(f'\n\nUh oh!! A wild {random_encounter.Name} appeared!!\n\n')

            # Let the user end program (run), or fight (continue)
            try:
                fight_or_run = input(f"Will you 'fight' {random_encounter.Name}? Or 'run'? ")
            except KeyboardInterrupt:
                sys.exit()
            print("During this phase of the game, press 'ENTER' to go through the battle.")

            # Fight the wild encounter!
            if fight_or_run.count('f') >= 1:
                pokemon_battle(random_encounter)
                print(f"\nThat was a tough battle.")
                try:
                    keep_playing = input("\nWould you like to form a new party and play again? (yes or no): ")
                except KeyboardInterrupt:
                    sys.exit()

                # Reset the Pokemon Party and Matchmaker if they want to play again
                if keep_playing.count('y') >= 1:
                    PokemonTrainer.pokemon_party = set()
                    PokemonTrainer.mm_funcs = list()
                    PokemonTrainer.mm_questions = list()
                    continue
                else:
                    break
                
            # If they don't want to fight, escape battle
            else:
                print(f'You have successfully escaped {random_encounter.Name}!')
                break
