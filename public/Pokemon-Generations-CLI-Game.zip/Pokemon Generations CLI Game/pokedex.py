"""
Nathan Spinetti
Class: CS 521 - Fall 2
Date: 12/16/23
Term Project
Pokedex class to get and set Pokedex as well as provide a 
random Pokemon from Pokedex.
"""

from pokemon import Pokemon
import random
from pokemon_trainer import PokemonTrainer
import copy

class Pokedex(PokemonTrainer):
    ''' Set the active Pokedex based on Generation chosen. '''
    
    def __init__(self, gen_num):
        self.generation = gen_num
        self.pokemon = self.get_pokemon(gen_num)
        self.random_pokemon = self.select_random_pokemon()

    def __str__(self):
        return f"This Pokedex is for Generation {self.generation}."
    
    def __repr__(self):
        return "Pokedex(1)"

    def get_pokemon(self, gen_num):
        ''' Get all the Pokemon from selected Generation via text file. '''
        pokedex = {}
        try:
            # Get file of chosen generation and set_pokedex
            with open(f'Pokemon Generations/pokemon_generation_{gen_num}.txt', 'r') as file:
                pokedex = self.set_pokedex(file)
        except Exception as e:
            print(f"An error occurred: {e}")
        return pokedex

    def set_pokedex(self, gen_file):
        ''' Set the Pokedex based on input file. '''
        pokedex = {}
        
        # Get the keys from the first line
        keys = gen_file.readline().strip().split(',')
        
        # Loop through each Pokemon in file
        for line in gen_file:
            values = line.strip().split(',')
            line_dict = dict(zip(keys, values))  # Create a dict for each Pokemon (line)
            primary_key = values[0]  # Get the Number attr of each Pokemon
            pokedex[primary_key] = Pokemon(line_dict)  # Set Pokedex value to a new Pokemon
        return pokedex
    
    def select_random_pokemon(self):
        ''' Choose a random Pokemon at end of Pokedex for the wild encounter. '''
        if self.pokemon:
            # Select one of the last 20 Pokemon in Pokedex
            pokemon_selection = list(self.pokemon.items())[-20:]
            # Return a deepcopy of it as to not mess with Pokemon base attr
            return copy.deepcopy(random.choice(pokemon_selection)[1])
        else:
            return None